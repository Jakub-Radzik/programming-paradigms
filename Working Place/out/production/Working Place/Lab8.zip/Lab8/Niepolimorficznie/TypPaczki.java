package Lab8.Niepolimorficznie;

public enum TypPaczki {
    PROSTOPADLOSCIAN,
    KULA,
    WALEC
//   GRANIASTOSLUP
}


package Lab8.Polimorficzna;

import static java.lang.Math.*;

public abstract class Paczka {

    public abstract double objetosc();

}

package Cwiki.java;

public class FullException extends Exception {

    public FullException(String message) {
        super(message);
    }

    public FullException() {
        super();
    }
}

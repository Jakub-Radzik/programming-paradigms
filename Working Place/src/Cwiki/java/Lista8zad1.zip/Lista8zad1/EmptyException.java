package Cwiki.java;

public class EmptyException extends Exception {

    public EmptyException() {
    }

    public EmptyException(String message) {
        super(message);
    }
}
